const express = require('express');
const router = express.Router();
const hp = require('../controller/HpController');

router.get('/', hp.nom);     
router.get('/home', hp.nom);        
router.get('/about', hp.about); 
router.get('/products', hp.products); 
router.get('/testimonial', hp.testimonial); 
router.get('/contact', hp.contact); 

module.exports = router;

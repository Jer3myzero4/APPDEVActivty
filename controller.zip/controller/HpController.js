const ph = {
    nom: (req, res) => {
      res.render('index', { page: 'home' }); // Render start.ejs as the home page
    },
    about: (req, res) => {
      res.render('aboutview', { page: 'about' }); // Render about page
    },
    contact: (req, res) => {
        res.render('contactview', { page: 'contact' }); // Render about page
      },
      products: (req, res) => {
        res.render('productsview', { page: 'products' }); // Render about page
      },
      testimonial: (req, res) => {
        res.render('testimonialview', { page: 'testimonial' }); // Render about page
      }
  };
  
  module.exports = ph;
  